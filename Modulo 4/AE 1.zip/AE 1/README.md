# Proyectos-Grupales-awake-bootcamp
 grupo 2
Trabajos grupales de equipo 2 del bootcamp fullstack python de AwakeLabs.
#### Integrantes:

 - Patricio Espinoza
 - Rafael Jara
 - Pablo Poblete
 - Franco Fuentes 
 - Francisco Olivares

